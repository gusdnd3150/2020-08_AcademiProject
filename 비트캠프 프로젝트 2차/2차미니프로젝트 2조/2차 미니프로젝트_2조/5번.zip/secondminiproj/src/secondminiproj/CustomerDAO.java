package secondminiproj;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class CustomerDAO {
	private DataSource dataFactory;
	private Connection con;
	private PreparedStatement pstmt;

	public CustomerDAO() {
		try {
			Context ctx = new InitialContext();
			Context envContext = (Context) ctx.lookup("java:/comp/env");
			dataFactory = (DataSource) envContext.lookup("jdbc/oracle");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public HashMap<String, String> searchCustomer(String id) {
		HashMap<String, String> map = new HashMap();
		try {
			con = dataFactory.getConnection();
			String query = " SELECT * FROM t_member WHERE id LIKE ?";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, id);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()) {
				map.put("id", rs.getString("id"));
				map.put("pwd", rs.getString("pwd"));
				map.put("name", rs.getString("name"));
			}
			rs.close();
			pstmt.close();
			con.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
		return map;
	}

	public void addCustomer(String id, String pwd, String name) {
		try {
			con = dataFactory.getConnection();
			String query = " SELECT * FROM t_member WHERE id=?";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, id);
			ResultSet rs = pstmt.executeQuery();
			if(!rs.next()) {
				System.out.println("inserttttt");
				query = " INSERT INTO t_member(id, pwd, name)";
				query += " VALUES(?, ?, ?) ";
				System.out.println(query);
				pstmt = con.prepareStatement(query);
				pstmt.setString(1, id);
				pstmt.setString(2, pwd);
				pstmt.setString(3, name);
			} else {
				query = " UPDATE t_member SET pwd=?, name=?";
				query += " WHERE id LIKE ?";
				System.out.println(query);
				pstmt = con.prepareStatement(query);
				pstmt.setString(1, pwd);
				pstmt.setString(2, name);
				pstmt.setString(3, id);
			}
			pstmt.executeUpdate();

			pstmt.close();
			con.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	public List<CustomerVO> listCustomer() {
		List<CustomerVO> customerList = new ArrayList();
		try {
			con = dataFactory.getConnection();
			String query = " SELECT * FROM t_member ORDER BY id ";
			pstmt = con.prepareStatement(query);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				String id = rs.getString("id");
				String pwd = rs.getString("pwd");
				String name = rs.getString("name");
				CustomerVO vo = new CustomerVO(id, pwd, name);
				customerList.add(vo);
			}
			
			rs.close();
			pstmt.close();
			con.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
		return customerList;
	}
}

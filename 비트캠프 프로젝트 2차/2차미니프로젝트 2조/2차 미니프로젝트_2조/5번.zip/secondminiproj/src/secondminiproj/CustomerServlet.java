package secondminiproj;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

/**
 * Servlet implementation class CustomerServlet
 */
@WebServlet("/customer")
public class CustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doHandle(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doHandle(request, response);
	}

	private void doHandle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html; charset=utf-8");
		PrintWriter writer = response.getWriter();
		CustomerDAO dao = new CustomerDAO();

		String command = request.getParameter("command");

		if("search".equals(command)) {
			String id = request.getParameter("id");
			HashMap<String, String> map = dao.searchCustomer(id);

			JSONObject customerObj = new JSONObject();
			customerObj.put("id", map.get("id"));
			customerObj.put("pwd", map.get("pwd"));
			customerObj.put("name", map.get("name"));
			String jsonInfo = customerObj.toJSONString();
			writer.print(jsonInfo);
		} else if("add".equals(command)) {
			String id = request.getParameter("id");
			String pwd = request.getParameter("pwd");
			String name = request.getParameter("name");
			
			dao.addCustomer(id, pwd, name);
		} else if("prev".equals(command) || "next".equals(command)) {
			List<CustomerVO> list = dao.listCustomer();
			JSONArray customersArray = new JSONArray();
			JSONObject obj = null;
			for(int i=0; i < list.size(); i++) {
				obj = new JSONObject();
				obj.put("id", list.get(i).getId());
				obj.put("pwd", list.get(i).getPwd());
				obj.put("name", list.get(i).getName());
				customersArray.add(obj);
			}
			String jsonInfo = customersArray.toJSONString();
			writer.print(jsonInfo);
		}
	}

}
